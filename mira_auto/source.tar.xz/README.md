# Mira Rastro 8 Ball — Android v2 (modo automático experimental)

## Função

Guia de mira sobreposto a aplicativos de sinuca. O modo **AUTO** captura **somente a tela** após consentimento explícito do Android (`MediaProjection`) e tenta reconhecer a bola branca, bolas coloridas e o ângulo da linha de mira. O canvas transparente traça deslocamento da branca, caminho da bola atingida e rebotes. O aplicativo não é injetado no processo do jogo e não injeta bibliotecas ou altera memória do 8 Ball Pool.

## Usar

1. Instale a versão 2 e abra **Mira Rastro 8 Ball**.
2. Escolha **ATIVAR MIRA AUTOMÁTICA**. Autorize a sobreposição.
3. Quando o Android pedir autorização para compartilhar a tela, escolha **Tela inteira** (caso ofereça essa opção).
4. Abra o **8 Ball Pool**; se os limites não corresponderem à área interna da mesa, no painel abra **MESA** e arraste as extremidades A/B.
5. Toque em **JOGAR**. A captura procura a branca, as outras bolas e a guia branca do próprio jogo. Movimentar a mira faz a previsão acompanhar o quadro identificado.
6. Se o jogo, a cor de feltro ou a mesa não forem reconhecidos, use **BRANCA / ALVO / DIREÇÃO** em modo manual. **AUTO: RETOMAR** volta à leitura automática.
7. Desligue no aplicativo ou na notificação.

## Limites

- O reconhecimento por cor e contraste é **experimental**. Não pode ser garantido para todos os temas de mesa, resoluções, celulares ou atualizações do jogo.
- É necessária a permissão do sistema a cada nova sessão de captura. A captura pode falhar quando o conteúdo é protegido contra compartilhamento de tela.
- As trajetórias ignoram atrito, força, efeito lateral, controle de força da tacada, e detalhes de caçapas. O traço de rebote representa aproximação geométrica.
- Overlay pode sofrer restrições de toque em Android 12+; foi configurado `FLAG_NOT_TOUCHABLE` com alfa de janela 0,65.
- As imagens não são transmitidas por rede; não há permissão de Internet no manifest.

## Compilar

Requisitos: JDK 17, Gradle 8.11+, Android SDK Platform 35 e Android Gradle Plugin 8.9.2 (declarado em `settings.gradle`).

```bash
gradle :app:assembleDebug
```

Arquivo: `app/build/outputs/apk/debug/app-debug.apk`.

Alternativa: use o workflow de GitHub Actions em `.github/workflows/build-apk.yml`.

Testes da lógica pura:

```bash
bash tools/test-physics.sh
javac -d /tmp/fdet_classes app/src/main/java/com/kindmops/mirarastro/FrameDetector.java tools/TestFrameDetector.java
java -cp /tmp/fdet_classes TestFrameDetector
```

Pacote: `com.kindmops.mirarastro`.
