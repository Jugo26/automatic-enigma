import com.kindmops.mirarastro.ShotPhysics;

/** Executar com: bash tools/test-physics.sh */
public final class CheckPhysics {
    private static void check(boolean c, String name) {
        if (!c) throw new AssertionError(name);
        System.out.println("OK: " + name);
    }
    private static boolean approx(float a, float b) { return Math.abs(a-b) < .1f; }
    public static void main(String[] args) {
        ShotPhysics.Rect table = new ShotPhysics.Rect(0,0,1000,500);
        ShotPhysics.Vec cue = new ShotPhysics.Vec(100,250);
        ShotPhysics.Result straight = ShotPhysics.simulate(cue,
                new ShotPhysics.Vec(400,250), new ShotPhysics.Vec(600,250),
                table, 10, 2, 2500);
        check(straight.hit, "colisão direta identificada");
        check(approx(straight.ghost.x, 380) && approx(straight.ghost.y,250),
                "bola fantasma no ponto de contato");
        check(straight.deflection.isEmpty(), "centro perfeito sem desvio lateral");
        check(!straight.object.isEmpty(), "trajetória da bola-alvo");
        check(straight.object.size() >= 2, "rebote da bola-alvo");

        ShotPhysics.Result miss = ShotPhysics.simulate(cue,
                new ShotPhysics.Vec(400,350), new ShotPhysics.Vec(600,250),
                table, 10, 1, 2000);
        check(!miss.hit, "tiro fora da bola-alvo");
        check(miss.cue.size() == 2, "rastro tem exatamente um rebote");
        check(approx(miss.cue.get(0).to.x,990), "rebote na borda corrigida pelo raio");

        ShotPhysics.Result cut = ShotPhysics.simulate(cue,
                new ShotPhysics.Vec(400,260), new ShotPhysics.Vec(600,250),
                table, 10, 1, 1800);
        check(cut.hit && !cut.deflection.isEmpty(), "corte gera desvio da branca");

        ShotPhysics.Result noBounce = ShotPhysics.simulate(cue,
                new ShotPhysics.Vec(400,350), new ShotPhysics.Vec(600,250),
                table, 10, 0, 2000);
        check(noBounce.cue.size() == 1, "zero rebotes respeitado");
    }
}
