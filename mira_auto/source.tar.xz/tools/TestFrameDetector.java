import com.kindmops.mirarastro.FrameDetector;
public class TestFrameDetector {
  public static void main(String[] args) {
    int w=400,h=240; int[] rgb=new int[w*h];
    java.util.Arrays.fill(rgb,0xFF256E6C);
    int cx=100,cy=115,tx=200,ty=115,r=8;
    for(int y=0;y<h;y++)for(int x=0;x<w;x++){
      if((x-cx)*(x-cx)+(y-cy)*(y-cy)<r*r)rgb[y*w+x]=0xFFFFFFFF;
      if((x-tx)*(x-tx)+(y-ty)*(y-ty)<r*r)rgb[y*w+x]=0xFFEE1616;
    }
    for(int x=120;x<=175;x++) if(x%10<6) rgb[cy*w+x]=0xFFFFFFFF;
    FrameDetector.State s=new FrameDetector(rgb,w,h).detect(20,20,380,220,8,null,null);
    if(s.cue==null||Math.abs(s.cue.x-cx)>3||Math.abs(s.cue.y-cy)>3)
      throw new AssertionError("branca não reconhecida");
    if(s.balls.isEmpty() || Math.abs(s.balls.get(0).x-tx)>3)
      throw new AssertionError("alvo não reconhecido");
    if(s.direction==null || s.direction.x<s.cue.x)
      throw new AssertionError("direção não encontrada");
    System.out.println("PASS: bola branca, alvo e direção da guia");
  }
}
