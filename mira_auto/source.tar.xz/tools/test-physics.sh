#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
OUT="$(mktemp -d)"
trap 'rm -rf "$OUT"' EXIT
javac -d "$OUT" app/src/main/java/com/kindmops/mirarastro/ShotPhysics.java tools/CheckPhysics.java
java -cp "$OUT" CheckPhysics
