package com.kindmops.mirarastro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Matemática pura: coordenadas em pixels da sobreposição. */
public final class ShotPhysics {
    private static final float EPS = 0.001f;

    private ShotPhysics() {}

    public static final class Vec {
        public final float x, y;
        public Vec(float x, float y) { this.x = x; this.y = y; }
        public Vec add(Vec b) { return new Vec(x + b.x, y + b.y); }
        public Vec sub(Vec b) { return new Vec(x - b.x, y - b.y); }
        public Vec mul(float a) { return new Vec(x * a, y * a); }
        public float dot(Vec b) { return x * b.x + y * b.y; }
        public float len() { return (float)Math.sqrt(x*x + y*y); }
        public Vec unit() { float l = len(); return l < EPS ? new Vec(1, 0) : mul(1f / l); }
        public float dist(Vec b) { return sub(b).len(); }
    }

    public static final class Rect {
        public final float left, top, right, bottom;
        public Rect(float l, float t, float r, float b) {
            left = Math.min(l, r); top = Math.min(t, b);
            right = Math.max(l, r); bottom = Math.max(t, b);
        }
        public Rect inset(float by) { return new Rect(left+by, top+by, right-by, bottom-by); }
        public Vec clamp(Vec p) {
            return new Vec(Math.max(left, Math.min(right, p.x)),
                           Math.max(top, Math.min(bottom, p.y)));
        }
    }

    public static final class Segment {
        public final Vec from, to;
        public Segment(Vec from, Vec to) { this.from = from; this.to = to; }
    }

    public static final class Result {
        public final List<Segment> cue;
        public final List<Segment> object;
        public final List<Segment> deflection;
        public final Vec ghost;
        public final boolean hit;
        Result(List<Segment> cue, List<Segment> object, List<Segment> deflection,
               Vec ghost, boolean hit) {
            this.cue = Collections.unmodifiableList(cue);
            this.object = Collections.unmodifiableList(object);
            this.deflection = Collections.unmodifiableList(deflection);
            this.ghost = ghost;
            this.hit = hit;
        }
    }

    private static final class Wall {
        final float t;
        final boolean xAxis;
        Wall(float t, boolean xAxis) { this.t = t; this.xAxis = xAxis; }
    }

    /** Limite da trajetória até o primeiro choque com a bola-alvo, incluindo rebotes. */
    public static Result simulate(Vec cue, Vec target, Vec aim, Rect table,
                                  float radius, int maxBounces, float maxDistance) {
        return simulateAll(cue, java.util.Collections.singletonList(target), aim, table,
                           radius, maxBounces, maxDistance);
    }

    /** Calcula o primeiro contato com qualquer bola visível, inclusive após rebotes. */
    public static Result simulateAll(Vec cue, java.util.List<Vec> targets, Vec aim, Rect table,
                                  float radius, int maxBounces, float maxDistance) {
        radius = Math.max(1f, radius);
        Rect centerBounds = table.inset(radius);
        Vec pos = centerBounds.clamp(cue);
        Vec dir = aim.sub(cue).unit();
        List<Segment> cueSegments = new ArrayList<>();
        List<Segment> objectSegments = new ArrayList<>();
        List<Segment> deflectionSegments = new ArrayList<>();
        Vec ghost = null;
        boolean hit = false;
        float left = Math.max(0, maxDistance);

        for (int bounce = 0; bounce <= maxBounces && left > EPS; bounce++) {
            Wall wall = nextWall(pos, dir, centerBounds);
            float wallT = wall == null ? Float.POSITIVE_INFINITY : wall.t;
            float ballT = Float.POSITIVE_INFINITY;
            Vec obj = null;
            for (Vec t : targets) {
                Vec candidate = centerBounds.clamp(t);
                float ct = circleHit(pos, dir, candidate, 2f * radius);
                if (ct < ballT) { ballT=ct; obj=candidate; }
            }
            float until = Math.min(Math.min(wallT, ballT), left);
            if (!Float.isFinite(until) || until < 0) break;
            Vec end = pos.add(dir.mul(until));
            cueSegments.add(new Segment(pos, end));
            left -= until;
            if (obj != null && ballT <= until + EPS && ballT < wallT - EPS) {
                ghost = end;
                hit = true;
                Vec normal = obj.sub(ghost).unit();
                Vec objectDir = normal;
                objectSegments.addAll(traceRails(obj, objectDir, centerBounds, maxBounces,
                        Math.min(maxDistance * 0.65f, Math.max(table.right-table.left,
                                 table.bottom-table.top) * 1.45f)));
                Vec slip = dir.sub(normal.mul(dir.dot(normal)));
                if (slip.len() > 0.035f) {
                    deflectionSegments.addAll(traceRails(ghost, slip.unit(), centerBounds,
                            Math.min(1, maxBounces), maxDistance * Math.min(0.5f, slip.len() * 0.7f)));
                }
                break;
            }
            if (wall == null || wallT > until + EPS || bounce == maxBounces) break;
            dir = wall.xAxis ? new Vec(-dir.x, dir.y) : new Vec(dir.x, -dir.y);
            pos = end;
        }
        return new Result(cueSegments, objectSegments, deflectionSegments, ghost, hit);
    }

    private static List<Segment> traceRails(Vec from, Vec d, Rect bounds,
                                            int bounceCount, float distance) {
        List<Segment> segments = new ArrayList<>();
        Vec pos = bounds.clamp(from);
        Vec dir = d.unit();
        float left = Math.max(0f, distance);
        for (int i = 0; i <= bounceCount && left > EPS; i++) {
            Wall wall = nextWall(pos, dir, bounds);
            float t = wall == null ? left : Math.min(left, wall.t);
            Vec end = pos.add(dir.mul(t));
            segments.add(new Segment(pos, end));
            left -= t;
            if (wall == null || wall.t > t + EPS) break;
            dir = wall.xAxis ? new Vec(-dir.x, dir.y) : new Vec(dir.x, -dir.y);
            pos = end;
        }
        return segments;
    }

    private static Wall nextWall(Vec p, Vec d, Rect b) {
        float best = Float.POSITIVE_INFINITY;
        boolean xAxis = false;
        if (d.x > EPS) { best = (b.right-p.x)/d.x; xAxis = true; }
        if (d.x < -EPS) { best = (b.left-p.x)/d.x; xAxis = true; }
        if (d.y > EPS) {
            float t = (b.bottom-p.y)/d.y;
            if (t < best - EPS) { best = t; xAxis = false; }
        }
        if (d.y < -EPS) {
            float t = (b.top-p.y)/d.y;
            if (t < best - EPS) { best = t; xAxis = false; }
        }
        return Float.isFinite(best) && best >= -EPS ? new Wall(Math.max(0, best), xAxis) : null;
    }

    /** Interseção positiva de raio sem assumir bola perfeitamente alinhada. */
    private static float circleHit(Vec origin, Vec d, Vec c, float radius) {
        Vec oc = origin.sub(c);
        float b = oc.dot(d);
        float k = oc.dot(oc) - radius*radius;
        float disc = b*b - k;
        if (disc < 0) return Float.POSITIVE_INFINITY;
        float t = -b - (float)Math.sqrt(disc);
        return t > EPS ? t : Float.POSITIVE_INFINITY;
    }
}
