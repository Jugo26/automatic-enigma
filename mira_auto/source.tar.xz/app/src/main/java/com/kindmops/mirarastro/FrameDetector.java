package com.kindmops.mirarastro;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

/** Detector aproximado de bolas e da linha de mira em pixels RGB, sem SDK nem OpenCV.
 *  Coordenadas de entrada e saída são pixels do quadro reduzido. */
public final class FrameDetector {
    public static final class Point {
        public final float x, y;
        public Point(float x, float y) { this.x=x; this.y=y; }
    }
    public static final class State {
        public final Point cue, direction;
        public final List<Point> balls;
        public final float confidence;
        State(Point cue, Point direction, List<Point> balls, float confidence) {
            this.cue=cue; this.direction=direction;
            this.balls=Collections.unmodifiableList(balls); this.confidence=confidence;
        }
    }
    private static final class Blob {
        float x,y;
        int area, width,height;
        float score;
        Blob(float x,float y,int a,int w,int h,float s){this.x=x;this.y=y;area=a;width=w;height=h;score=s;}
    }
    private final int[] queue;
    private final byte[] mask;
    private final int[] frame;
    private final int width, height;
    private int x0,y0,x1,y1;
    private float radius;
    private int felt;

    public FrameDetector(int[] rgb, int width, int height) {
        if (width<=0 || height<=0 || rgb.length<width*height) throw new IllegalArgumentException("frame");
        this.frame=rgb; this.width=width; this.height=height;
        this.mask=new byte[width*height]; this.queue=new int[width*height];
    }
    public State detect(float left, float top, float right, float bottom, float ballRadius,
                        Point lastCue, Point lastAim) {
        radius=Math.max(3f,ballRadius);
        x0=Math.max(1,(int)Math.min(left,right)+Math.round(radius));
        y0=Math.max(1,(int)Math.min(top,bottom)+Math.round(radius));
        x1=Math.min(width-2,(int)Math.max(left,right)-Math.round(radius));
        y1=Math.min(height-2,(int)Math.max(top,bottom)-Math.round(radius));
        if(x1<=x0 || y1<=y0) return new State(null,null,new ArrayList<>(),0f);
        felt=sampleFelt();
        List<Blob> whites=blobs(true);
        Blob best=null;
        for (Blob b:whites) {
            float expected=(float)(Math.PI*radius*radius);
            float sizeFit=Math.min(b.area/expected,expected/b.area);
            float distance=lastCue==null?0f:(float)Math.hypot(b.x-lastCue.x,b.y-lastCue.y);
            b.score=sizeFit*4f+Math.max(0f,2f-distance/(radius*10f));
            if(best==null || b.score>best.score) best=b;
        }
        if(best==null) return new State(null,null,new ArrayList<>(),0f);
        Point cue=new Point(best.x,best.y);
        List<Blob> colors=blobs(false);
        List<Point> balls=new ArrayList<>();
        for(Blob b:colors) if(Math.hypot(b.x-cue.x,b.y-cue.y)>radius*1.5f)
            balls.add(new Point(b.x,b.y));
        Point aim=findAim(cue,lastAim);
        float confidence=aim==null?0.35f:Math.min(1f,0.5f+best.score/12f);
        return new State(cue,aim,balls,confidence);
    }
    private int sampleFelt() {
        // Mediana aproximada por canal para tolerar temas de mesa verdes, azuis e escuros.
        int[] rs=new int[49],gs=new int[49],bs=new int[49]; int i=0;
        for(int j=1;j<=7;j++) for(int k=1;k<=7;k++){
            int x=x0+(x1-x0)*k/8, y=y0+(y1-y0)*j/8, c=frame[y*width+x];
            rs[i]=(c>>16)&255; gs[i]=(c>>8)&255; bs[i]=c&255; i++;
        }
        java.util.Arrays.sort(rs);java.util.Arrays.sort(gs);java.util.Arrays.sort(bs);
        return (rs[24]<<16)|(gs[24]<<8)|bs[24];
    }
    private boolean white(int c){
        int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
        return Math.min(r,Math.min(g,b))>=175 && Math.max(r,Math.max(g,b))-Math.min(r,Math.min(g,b))<=60;
    }
    private boolean colored(int c){
        int r=(c>>16)&255,g=(c>>8)&255,b=c&255;
        int mx=Math.max(r,Math.max(g,b)),mn=Math.min(r,Math.min(g,b));
        if(mx<65 || mx-mn<42) return false;
        int dr=r-((felt>>16)&255),dg=g-((felt>>8)&255),db=b-(felt&255);
        return dr*dr+dg*dg+db*db>60*60;
    }
    private List<Blob> blobs(boolean cueMask){
        java.util.Arrays.fill(mask,(byte)0);
        for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++){
            int idx=y*width+x;
            if(cueMask?white(frame[idx]):colored(frame[idx]))mask[idx]=1;
        }
        List<Blob> out=new ArrayList<>();
        float minArea=cueMask?0.25f:0.12f;
        float maxArea=cueMask?2.5f:2.3f;
        for(int y=y0;y<=y1;y++)for(int x=x0;x<=x1;x++){
            int seed=y*width+x;
            if(mask[seed]!=1)continue;
            int h=0,t=0;queue[t++]=seed;mask[seed]=2;
            long sx=0,sy=0;int minX=x,maxX=x,minY=y,maxY=y;
            while(h<t){
                int q=queue[h++],qx=q%width,qy=q/width;
                sx+=qx;sy+=qy;
                if(qx<minX)minX=qx;if(qx>maxX)maxX=qx;
                if(qy<minY)minY=qy;if(qy>maxY)maxY=qy;
                if(qx>x0 && mask[q-1]==1){mask[q-1]=2;queue[t++]=q-1;}
                if(qx<x1 && mask[q+1]==1){mask[q+1]=2;queue[t++]=q+1;}
                if(qy>y0 && mask[q-width]==1){mask[q-width]=2;queue[t++]=q-width;}
                if(qy<y1 && mask[q+width]==1){mask[q+width]=2;queue[t++]=q+width;}
            }
            float expected=(float)Math.PI*radius*radius;
            int bw=maxX-minX+1,bh=maxY-minY+1;
            if(t<minArea*expected || t>maxArea*expected)continue;
            if(bw<radius*.65f || bh<radius*.65f || bw>radius*2.8f || bh>radius*2.8f)continue;
            if((float)Math.max(bw,bh)/Math.max(1,Math.min(bw,bh))>1.8f)continue;
            out.add(new Blob((float)sx/t,(float)sy/t,t,bw,bh,0));
        }
        out.sort(Comparator.comparingDouble(a->-a.area));
        if(out.size()>24)out=new ArrayList<>(out.subList(0,24));
        return out;
    }
    private Point findAim(Point cue, Point lastAim){
        // Busca ângulo da linha branca/pontilhada que parte da bola branca.
        float end=Math.min((x1-x0),(y1-y0))*.65f;
        float best=-1f,angle=0f;
        for(int deg=0;deg<360;deg+=2){
            float a=(float)(deg*Math.PI/180.),dx=(float)Math.cos(a),dy=(float)Math.sin(a);
            int bright=0, samples=0;
            for(float t=radius*2.1f;t<end;t+=2.4f){
                int x=Math.round(cue.x+dx*t),y=Math.round(cue.y+dy*t);
                if(x<x0 || x>x1 || y<y0 || y>y1)break;
                int c=frame[y*width+x]; samples++;
                if(white(c))bright++;
            }
            if(samples<6)continue;
            float score=bright/(float)samples;
            if(lastAim!=null){
                float dx0=lastAim.x-cue.x,dy0=lastAim.y-cue.y;
                if(dx0*dx+dy0*dy>0)score+=0.015f;
            }
            if(score>best){best=score;angle=a;}
        }
        // Se não há linha clara, não inventar direção.
        if(best<0.095f)return null;
        return new Point(cue.x+(float)Math.cos(angle)*radius*8f,
                         cue.y+(float)Math.sin(angle)*radius*8f);
    }
}
