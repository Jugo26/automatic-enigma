package com.kindmops.mirarastro;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.content.Context;
import android.media.projection.MediaProjectionManager;
import android.os.Bundle;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public final class MainActivity extends Activity {
    private static final int REQUEST_CAPTURE=8103;
    private boolean pendingOverlayPermission;
    private boolean pendingAutoOverlayPermission;
    private TextView permissionStatus;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        int pad = dp(24);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFF080F1D);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(pad, dp(45), pad, dp(30));
        scroll.addView(root);
        setContentView(scroll);

        TextView accent = label("●  MIRA RASTRO  /  ANDROID", 12, 0xFF2BF2CA, true);
        root.addView(accent);
        TextView heading = label("A jogada na\nsua mira.", 34, Color.WHITE, true);
        heading.setPadding(0, dp(20), 0, dp(12));
        root.addView(heading);
        TextView desc = label("Rastro animado, colisão com a bola-alvo e até 3 rebotes na mesa, em uma sobreposição transparente.", 15, 0xFFAAC0D0, false);
        root.addView(desc);

        LinearLayout info = new LinearLayout(this);
        info.setOrientation(LinearLayout.VERTICAL);
        info.setPadding(dp(17),dp(15),dp(17),dp(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xFF142637); bg.setCornerRadius(dp(14));
        bg.setStroke(dp(1), 0xFF275164);
        info.setBackground(bg);
        LinearLayout.LayoutParams infoLp = new LinearLayout.LayoutParams(-1,-2);
        infoLp.setMargins(0, dp(30),0,dp(24));
        root.addView(info, infoLp);
        info.addView(label("MODO AUTOMÁTICO + MODO MANUAL", 13, 0xFF2BF2CA, true));
        TextView description = label("AUTO: permita sobreposição e captura da tela inteira, depois abra o 8 Ball Pool. Calibre os limites da mesa uma vez no painel. O app tenta detectar a branca, as demais bolas e a linha de mira.\n\nMANUAL: marque MESA, BRANCA, ALVO e DIREÇÃO; toque em JOGAR para liberar os toques.", 13, 0xFFE2E9F1, false);
        description.setLineSpacing(dp(5),1f);
        description.setPadding(0, dp(12), 0, 0);
        info.addView(description);

        permissionStatus = label("Permissão de sobreposição: verificando...", 13, 0xFFAAC0D0, false);
        permissionStatus.setPadding(0,0,0,dp(12));
        root.addView(permissionStatus);
        root.addView(button("ATIVAR MIRA AUTOMÁTICA", true, this::requestAuto));
        Button manual=button("ATIVAR MIRA MANUAL",false,this::requestOrStart);
        LinearLayout.LayoutParams manualLp=new LinearLayout.LayoutParams(-1,dp(54));
        manualLp.setMargins(0,dp(12),0,0);
        root.addView(manual,manualLp);
        Button off = button("DESATIVAR MIRA", false,
                () -> stopService(new Intent(this, AimOverlayService.class)));
        LinearLayout.LayoutParams offLp = new LinearLayout.LayoutParams(-1, dp(54));
        offLp.setMargins(0, dp(12), 0,0);
        root.addView(off, offLp);
        TextView footer = label("A captura requer autorização a cada sessão e roda só no aparelho. Não modifica o 8 Ball Pool. A detecção é experimental e pode falhar com temas de mesa, bolinhas listradas e guias de mira pouco visíveis. Sem efeito, atrito ou força real.", 12, 0xFF8198A9, false);
        footer.setPadding(0,dp(23),0,0);
        root.addView(footer);
    }

    private int dp(float v) { return (int)(v*getResources().getDisplayMetrics().density+.5f); }

    private TextView label(String txt, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(txt);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String text, boolean primary, Runnable action) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextColor(primary ? 0xFF06151B : Color.WHITE);
        b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(primary ? 0xFF2BF2CA : 0xFF1B3142);
        bg.setCornerRadius(dp(14));
        b.setBackground(bg);
        b.setOnClickListener(v -> action.run());
        b.setGravity(Gravity.CENTER);
        if (primary) b.setLayoutParams(new LinearLayout.LayoutParams(-1,dp(56)));
        return b;
    }

    private void requestOrStart() {
        if (!Settings.canDrawOverlays(this)) {
            pendingOverlayPermission = true;
            Intent permission = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(permission);
        } else startOverlay();
    }

    private void requestAuto() {
        if (!Settings.canDrawOverlays(this)) {
            pendingAutoOverlayPermission=true;
            Intent permission=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:"+getPackageName()));
            startActivity(permission);
            return;
        }
        MediaProjectionManager mgr=(MediaProjectionManager)getSystemService(Context.MEDIA_PROJECTION_SERVICE);
        startActivityForResult(mgr.createScreenCaptureIntent(),REQUEST_CAPTURE);
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data) {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode==REQUEST_CAPTURE && resultCode==RESULT_OK && data!=null) {
            Intent service=new Intent(this,AimOverlayService.class);
            service.putExtra(AimOverlayService.EXTRA_AUTO,true);
            service.putExtra(AimOverlayService.EXTRA_RESULT_CODE,resultCode);
            service.putExtra(AimOverlayService.EXTRA_RESULT_DATA,data);
            startForegroundService(service);
            moveTaskToBack(true);
        }
    }

    private void startOverlay() {
        Intent service = new Intent(this, AimOverlayService.class);
        startForegroundService(service);
        // Não abre o jogo sozinho: usuário pode usar qualquer aplicativo de sinuca.
        moveTaskToBack(true);
    }

    @Override protected void onResume() {
        super.onResume();
        boolean granted = Settings.canDrawOverlays(this);
        if (permissionStatus != null) permissionStatus.setText(granted ?
                "Permissão de sobreposição: LIBERADA" : "Permissão de sobreposição: NECESSÁRIA");
        if (pendingAutoOverlayPermission && granted) {
            pendingAutoOverlayPermission=false;
            requestAuto();
        } else if (pendingOverlayPermission && granted) {
            pendingOverlayPermission = false;
            startOverlay();
        }
    }
}
