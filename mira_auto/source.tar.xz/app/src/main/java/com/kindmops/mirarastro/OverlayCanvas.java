package com.kindmops.mirarastro;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.DashPathEffect;
import android.graphics.Paint;
import android.graphics.RectF;
import android.view.MotionEvent;
import android.view.View;

import java.util.List;
import java.util.ArrayList;
import java.util.Collections;

/** Canvas transparente com pontos manuais de calibração e trilha animada. */
public final class OverlayCanvas extends View {
    public enum Mode { PLAY, TABLE, CUE, TARGET, AIM }

    private static final int AQUA = Color.rgb(39, 247, 209);
    private static final int GOLD = Color.rgb(255, 209, 87);
    private static final int BLUE = Color.rgb(95, 176, 255);
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final SharedPreferences prefs;
    private final float density;
    private Mode mode = Mode.CUE;

    private ShotPhysics.Rect table;
    private ShotPhysics.Vec cue, objectBall, aim;
    private float radius;
    private int bounces = 2;
    private float lengthFactor = 2.5f;
    private boolean initialized;
    private boolean draggingEnd;
    private boolean automaticMode;
    private ShotPhysics.Vec detectedCue, detectedAim;
    private List<ShotPhysics.Vec> detectedBalls = Collections.emptyList();
    private long lastDetectionMs;

    public ShotPhysics.Rect getTableBounds() { return table; }
    public boolean isAutomaticMode() { return automaticMode; }
    public void setAutomaticMode(boolean enabled) {
        automaticMode=enabled;
        if (!enabled) { detectedCue=null; detectedAim=null; detectedBalls=Collections.emptyList(); }
        invalidate();
    }
    public boolean isTracking() {
        return automaticMode && detectedCue!=null && detectedAim!=null &&
                android.os.SystemClock.uptimeMillis()-lastDetectionMs<1800;
    }
    /** Chamar somente na UI thread. captureWidth/Height são as dimensões efetivas do frame. */
    public void setDetectedFrame(FrameDetector.State state, int captureWidth, int captureHeight) {
        if (!automaticMode || state==null) return;
        if (state.cue==null || state.direction==null) {
            if (android.os.SystemClock.uptimeMillis()-lastDetectionMs>1800) {
                detectedCue=null; detectedAim=null; detectedBalls=Collections.emptyList();
            }
            return;
        }
        float sx=getWidth()/(float)Math.max(1,captureWidth);
        float sy=getHeight()/(float)Math.max(1,captureHeight);
        detectedCue=new ShotPhysics.Vec(state.cue.x*sx,state.cue.y*sy);
        detectedAim=new ShotPhysics.Vec(state.direction.x*sx,state.direction.y*sy);
        List<ShotPhysics.Vec> points=new ArrayList<>();
        for (FrameDetector.Point bp:state.balls)
            points.add(new ShotPhysics.Vec(bp.x*sx,bp.y*sy));
        detectedBalls=points;
        lastDetectionMs=android.os.SystemClock.uptimeMillis();
        invalidate();
    }

    public OverlayCanvas(Context context) {
        super(context);
        density = getResources().getDisplayMetrics().density;
        prefs = context.getSharedPreferences("calibration", Context.MODE_PRIVATE);
        bounces = prefs.getInt("bounces", 2);
        radius = prefs.getFloat("radius", 0f);
        lengthFactor = prefs.getFloat("length", 2.5f);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    public Mode getMode() { return mode; }
    public void setMode(Mode newMode) { mode = newMode; invalidate(); }
    public int getBounces() { return bounces; }
    public void cycleBounces() {
        bounces = (bounces + 1) % 4;
        prefs.edit().putInt("bounces", bounces).apply();
        invalidate();
    }
    public float getRadius() { return radius; }
    public void changeRadius(float step) {
        radius = Math.max(3 * density, Math.min(32 * density, radius + step*density));
        prefs.edit().putFloat("radius", radius).apply();
        invalidate();
    }
    public boolean isLongTrack() { return lengthFactor > 2f; }
    public void toggleTrackLength() {
        lengthFactor = lengthFactor > 2f ? 1.2f : 2.5f;
        prefs.edit().putFloat("length", lengthFactor).apply();
        invalidate();
    }
    public void reset() {
        prefs.edit().clear().apply();
        initialized = false;
        bounces = 2;
        radius = 0f;
        lengthFactor = 2.5f;
        initPositions(getWidth(), getHeight());
        invalidate();
    }

    @Override protected void onSizeChanged(int w, int h, int oldW, int oldH) {
        super.onSizeChanged(w, h, oldW, oldH);
        if (w <= 0 || h <= 0) return;
        initialized = false;
        initPositions(w, h);
    }

    private void initPositions(int w, int h) {
        if (w <= 0 || h <= 0) return;
        if (prefs.contains("left")) {
            table = new ShotPhysics.Rect(prefs.getFloat("left", .08f)*w,
                    prefs.getFloat("top", .14f)*h,
                    prefs.getFloat("right", .92f)*w,
                    prefs.getFloat("bottom", .86f)*h);
            cue = new ShotPhysics.Vec(prefs.getFloat("cx", .5f)*w, prefs.getFloat("cy", .7f)*h);
            objectBall = new ShotPhysics.Vec(prefs.getFloat("tx", .5f)*w, prefs.getFloat("ty", .4f)*h);
            aim = new ShotPhysics.Vec(prefs.getFloat("ax", .5f)*w, prefs.getFloat("ay", .3f)*h);
        } else if (w < h) {
            table = new ShotPhysics.Rect(w*.09f, h*.15f, w*.91f, h*.85f);
            cue = new ShotPhysics.Vec(w*.49f, h*.71f);
            objectBall = new ShotPhysics.Vec(w*.55f, h*.39f);
            aim = new ShotPhysics.Vec(w*.57f, h*.22f);
        } else {
            table = new ShotPhysics.Rect(w*.08f, h*.17f, w*.92f, h*.83f);
            cue = new ShotPhysics.Vec(w*.27f, h*.53f);
            objectBall = new ShotPhysics.Vec(w*.66f, h*.46f);
            aim = new ShotPhysics.Vec(w*.81f, h*.43f);
        }
        if (radius <= 0) radius = Math.max(5*density, Math.min(w, h) * .024f);
        initialized = true;
    }

    private void save() {
        float w = Math.max(1, getWidth());
        float h = Math.max(1, getHeight());
        prefs.edit()
            .putFloat("left", table.left/w).putFloat("top", table.top/h)
            .putFloat("right", table.right/w).putFloat("bottom", table.bottom/h)
            .putFloat("cx", cue.x/w).putFloat("cy", cue.y/h)
            .putFloat("tx", objectBall.x/w).putFloat("ty", objectBall.y/h)
            .putFloat("ax", aim.x/w).putFloat("ay", aim.y/h)
            .putFloat("radius", radius).apply();
    }

    private void stroke(int color, float width, int alpha) {
        p.reset(); p.setAntiAlias(true);
        p.setColor(color); p.setAlpha(alpha);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(width*density);
    }

    private void line(Canvas c, ShotPhysics.Vec a, ShotPhysics.Vec b) {
        c.drawLine(a.x, a.y, b.x, b.y, p);
    }

    private void path(Canvas c, List<ShotPhysics.Segment> segments, int color, long timeMs) {
        // brilho amplo e traço contínuo de baixo contraste
        stroke(color, 7f, 28);
        for (ShotPhysics.Segment s : segments) line(c, s.from, s.to);
        stroke(color, 2.1f, 160);
        for (ShotPhysics.Segment s : segments) line(c, s.from, s.to);
        stroke(color, 3.3f, 255);
        float dash = 17*density, gap = 11*density;
        float phase = -((timeMs / 22f) % (dash + gap));
        p.setPathEffect(new DashPathEffect(new float[]{dash, gap}, phase));
        for (ShotPhysics.Segment s : segments) line(c, s.from, s.to);
        p.setPathEffect(null);
    }

    private void ring(Canvas c, ShotPhysics.Vec at, float r, int color, int alpha) {
        stroke(color, 1.7f, alpha);
        c.drawCircle(at.x, at.y, r, p);
        p.setStyle(Paint.Style.FILL);
        p.setAlpha(Math.min(alpha, 70));
        c.drawCircle(at.x, at.y, Math.max(2*density, r*.22f), p);
    }

    private void handle(Canvas c, ShotPhysics.Vec pt, int color, String label) {
        ring(c, pt, 10*density, color, 255);
        p.setColor(Color.WHITE); p.setStyle(Paint.Style.FILL); p.setAlpha(240);
        p.setTextSize(11*density); p.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        c.drawText(label, pt.x + 13*density, pt.y-12*density, p);
    }

    @Override protected void onDraw(Canvas c) {
        super.onDraw(c);
        if (!initialized) initPositions(getWidth(), getHeight());
        if (!initialized) return;
        long now = android.os.SystemClock.uptimeMillis();
        float maxPath = Math.max(getWidth(), getHeight()) * lengthFactor;
        boolean live=isTracking();
        ShotPhysics.Result result = automaticMode
                ? (live ? ShotPhysics.simulateAll(detectedCue, detectedBalls, detectedAim,
                    table, radius, bounces, maxPath) : null)
                : ShotPhysics.simulate(cue, objectBall, aim, table, radius, bounces, maxPath);
        stroke(AQUA, mode == Mode.PLAY ? .9f : 1.5f, mode == Mode.PLAY ? 70 : 180);
        RectF rect = new RectF(table.left, table.top, table.right, table.bottom);
        p.setPathEffect(new DashPathEffect(new float[]{8*density, 8*density}, 0));
        c.drawRoundRect(rect, 8*density, 8*density, p);
        p.setPathEffect(null);

        if (result!=null) {
            path(c, result.cue, AQUA, now);
            path(c, result.object, GOLD, now);
            path(c, result.deflection, BLUE, now);
            ring(c, live ? detectedCue : cue, radius, Color.WHITE, mode == Mode.PLAY ? 140 : 255);
            if (!automaticMode) ring(c, objectBall, radius, GOLD, mode == Mode.PLAY ? 130 : 255);
            if (result.hit && result.ghost != null) ring(c, result.ghost, radius, AQUA, 255);
        }
        if (automaticMode && !live) {
            p.setColor(GOLD);p.setStyle(Paint.Style.FILL);p.setAlpha(225);
            p.setTextSize(13*density);
            c.drawText("AUTO: aguardando detecção confiável da mira",14*density,
                       getHeight()-22*density,p);
        }
        if (mode != Mode.PLAY && !automaticMode) {
            handle(c, cue, Color.WHITE, "BRANCA");
            handle(c, objectBall, GOLD, "ALVO");
            handle(c, aim, BLUE, "DIREÇÃO");
            if (mode == Mode.TABLE) {
                handle(c, new ShotPhysics.Vec(table.left, table.top), AQUA, "A");
                handle(c, new ShotPhysics.Vec(table.right, table.bottom), AQUA, "B");
            }
            p.setStyle(Paint.Style.FILL); p.setColor(Color.WHITE); p.setAlpha(230);
            p.setTextSize(11*density);
            c.drawText("AJUSTE: toque ou arraste a posição selecionada", 12*density,
                    getHeight()-26*density, p);
        }
        postInvalidateDelayed(36);
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (mode == Mode.PLAY) return false;
        if (!initialized) return true;
        int action = event.getActionMasked();
        float x = Math.max(0, Math.min(getWidth(), event.getX()));
        float y = Math.max(0, Math.min(getHeight(), event.getY()));
        if (action == MotionEvent.ACTION_DOWN) {
            if (mode == Mode.TABLE) {
                float d1 = (float)Math.hypot(x-table.left, y-table.top);
                float d2 = (float)Math.hypot(x-table.right, y-table.bottom);
                draggingEnd = d2 < d1;
            }
            getParent().requestDisallowInterceptTouchEvent(true);
        }
        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_MOVE) {
            ShotPhysics.Vec pt = new ShotPhysics.Vec(x,y);
            switch (mode) {
                case TABLE:
                    float l = table.left, t = table.top, r = table.right, b = table.bottom;
                    if (draggingEnd) {
                        r = Math.max(l + 90*density, x);
                        b = Math.max(t + 90*density, y);
                    } else {
                        l = Math.min(r-90*density, x);
                        t = Math.min(b-90*density, y);
                    }
                    table = new ShotPhysics.Rect(l, t, r, b);
                    break;
                case CUE:
                    ShotPhysics.Vec delta = pt.sub(cue);
                    cue = pt;
                    aim = aim.add(delta);
                    break;
                case TARGET: objectBall = pt; break;
                case AIM: aim = pt; break;
                default: break;
            }
            invalidate();
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            save();
            return true;
        }
        return true;
    }
}
