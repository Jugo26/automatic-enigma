package com.kindmops.mirarastro;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.media.Image;
import android.media.ImageReader;
import android.media.projection.MediaProjection;
import android.media.projection.MediaProjectionManager;
import android.hardware.display.DisplayManager;
import android.hardware.display.VirtualDisplay;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.Looper;
import android.os.SystemClock;
import android.graphics.Point;
import android.graphics.PixelFormat;
import android.util.DisplayMetrics;
import java.nio.ByteBuffer;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class AimOverlayService extends Service {
    public static final String ACTION_STOP = "com.kindmops.mirarastro.STOP";
    public static final String EXTRA_AUTO = "capture_auto";
    public static final String EXTRA_RESULT_CODE = "capture_result_code";
    public static final String EXTRA_RESULT_DATA = "capture_result_data";
    private static final String CHANNEL = "mira_overlay_status";
    private static final int NOTIFICATION_ID = 2001;
    private static final int MINT = Color.rgb(39, 247, 209);
    private static final int BUTTON_DARK = Color.rgb(30, 49, 69);

    private WindowManager manager;
    private OverlayCanvas canvas;
    private WindowManager.LayoutParams canvasLp, panelLp;
    private LinearLayout panel;
    private TextView status;
    private Button goButton, collapseButton, bouncesButton, lengthButton;
    private boolean collapsed;
    private LinearLayout options;
    private Button autoButton;
    private MediaProjection projection;
    private MediaProjection.Callback projectionCallback;
    private VirtualDisplay virtualDisplay;
    private ImageReader imageReader;
    private HandlerThread captureThread;
    private Handler captureHandler;
    private boolean captureActive;
    private long lastFrameAt;
    private FrameDetector.Point previousCue,previousAim;
    private final Handler mainHandler=new Handler(Looper.getMainLooper());

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf(); return START_NOT_STICKY;
        }
        if (canvas == null) {
            manager = (WindowManager)getSystemService(Context.WINDOW_SERVICE);
            createOverlay();
            createPanel();
        }
        if (intent!=null && intent.getBooleanExtra(EXTRA_AUTO,false)) {
            startStatusNotification(true);
            startCapture(intent);
        } else if (!captureActive) {
            startStatusNotification(false);
        }
        refresh();
        return START_NOT_STICKY;
    }

    private int dp(float value) { return (int)(value*getResources().getDisplayMetrics().density + .5f); }

    private WindowManager.LayoutParams baseParams(int width, int height, int flags) {
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                width, height, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                flags, android.graphics.PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        if (Build.VERSION.SDK_INT >= 28) {
            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }
        return lp;
    }

    private void createOverlay() {
        canvas = new OverlayCanvas(this);
        canvasLp = baseParams(WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN |
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS |
                WindowManager.LayoutParams.FLAG_SECURE);
        // Android 12+ só encaminha toques sob uma janela SAW se sua opacidade <= 0.8.
        canvasLp.alpha = .65f;
        manager.addView(canvas, canvasLp);
    }

    private GradientDrawable background(int fill, int border) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(fill); bg.setCornerRadius(dp(12));
        bg.setStroke(dp(1), border);
        return bg;
    }

    private TextView text(String label, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(label); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String label, Runnable action) {
        Button b = new Button(this);
        b.setText(label); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setTextSize(TypedValue.COMPLEX_UNIT_SP, 11);
        b.setMinHeight(0); b.setMinimumHeight(0); b.setPadding(dp(4), dp(3), dp(4), dp(3));
        b.setBackground(background(BUTTON_DARK, Color.rgb(43, 67, 83)));
        b.setOnClickListener(v -> action.run());
        return b;
    }

    private void rowAdd(LinearLayout parent, Button... bs) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        for (Button b : bs) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(35), 1);
            lp.setMargins(dp(2), dp(2), dp(2), dp(2));
            row.addView(b, lp);
        }
        parent.addView(row);
    }

    private void createPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(7), dp(6), dp(7), dp(7));
        panel.setBackground(background(0xF20C1929, 0xB526DBC0));

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        TextView title = text("● MIRA RASTRO", 12, MINT, true);
        top.addView(title, new LinearLayout.LayoutParams(0, dp(30), 1));
        collapseButton = button("−", this::toggleCollapsed);
        top.addView(collapseButton, new LinearLayout.LayoutParams(dp(35), dp(30)));
        Button close = button("×", this::stopSelf);
        top.addView(close, new LinearLayout.LayoutParams(dp(35), dp(30)));
        panel.addView(top);
        // Arrastar pelo título reposiciona o painel.
        title.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY;
            int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        downX = e.getRawX(); downY = e.getRawY();
                        startX = panelLp.x; startY = panelLp.y;
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        panelLp.x = Math.max(0, startX + Math.round(e.getRawX()-downX));
                        panelLp.y = Math.max(0, startY + Math.round(e.getRawY()-downY));
                        manager.updateViewLayout(panel, panelLp);
                        return true;
                    case MotionEvent.ACTION_UP:
                        getSharedPreferences("calibration", MODE_PRIVATE).edit()
                                .putInt("panel_x", panelLp.x).putInt("panel_y", panelLp.y).apply();
                        return true;
                    default: return true;
                }
            }
        });
        options = new LinearLayout(this);
        options.setOrientation(LinearLayout.VERTICAL);
        status = text("AJUSTANDO • selecione um ponto", 10, 0xFFCCD9E4, false);
        status.setPadding(dp(4),dp(4),dp(3),dp(6));
        options.addView(status);
        goButton = button("▶ JOGAR", this::toggleMode);
        rowAdd(options, goButton);
        autoButton = button("AUTO: ABRIR", () -> {
            if (captureActive) {
                canvas.setAutomaticMode(!canvas.isAutomaticMode());
                if (canvas.isAutomaticMode()) {
                    canvas.setMode(OverlayCanvas.Mode.PLAY);
                    setCanvasTouchable(false);
                }
                refresh();
            } else {
                Intent ui=new Intent(this,MainActivity.class)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_SINGLE_TOP);
                startActivity(ui);
            }
        });
        rowAdd(options,autoButton);
        rowAdd(options,
                button("MESA", () -> choose(OverlayCanvas.Mode.TABLE)),
                button("BRANCA", () -> choose(OverlayCanvas.Mode.CUE)));
        rowAdd(options,
                button("ALVO", () -> choose(OverlayCanvas.Mode.TARGET)),
                button("DIREÇÃO", () -> choose(OverlayCanvas.Mode.AIM)));
        bouncesButton = button("REBOTES: 2", () -> {
            canvas.cycleBounces(); refresh();
        });
        lengthButton = button("RASTRO: LONGO", () -> {
            canvas.toggleTrackLength(); refresh();
        });
        rowAdd(options, bouncesButton, lengthButton);
        rowAdd(options,
                button("BOLA −", () -> canvas.changeRadius(-1.5f)),
                button("BOLA +", () -> canvas.changeRadius(1.5f)),
                button("RESET", () -> { canvas.reset(); refresh(); }));
        TextView legend = text("verde: branca  •  amarelo: alvo\nazul: desvio após contato", 9,
                0xFF99B1C4, false);
        legend.setPadding(dp(3), dp(5), dp(3), dp(1));
        options.addView(legend);
        panel.addView(options);

        panelLp = baseParams(dp(228), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL |
                WindowManager.LayoutParams.FLAG_SECURE);
        panelLp.x = getSharedPreferences("calibration", MODE_PRIVATE).getInt("panel_x", dp(12));
        panelLp.y = getSharedPreferences("calibration", MODE_PRIVATE).getInt("panel_y", dp(90));
        panelLp.alpha = .99f;
        manager.addView(panel, panelLp);
        refresh();
    }

    private void choose(OverlayCanvas.Mode selected) {
        canvas.setAutomaticMode(false);
        canvas.setMode(selected);
        setCanvasTouchable(true);
        refresh();
    }

    private void toggleMode() {
        boolean playing = canvas.getMode() != OverlayCanvas.Mode.PLAY;
        canvas.setMode(playing ? OverlayCanvas.Mode.PLAY : OverlayCanvas.Mode.CUE);
        canvas.setAutomaticMode(playing && captureActive);
        setCanvasTouchable(!playing);
        refresh();
    }

    private void setCanvasTouchable(boolean touchable) {
        if (canvasLp == null) return;
        if (touchable) canvasLp.flags &= ~WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        else canvasLp.flags |= WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE;
        manager.updateViewLayout(canvas, canvasLp);
    }

    private void refresh() {
        if (canvas == null || goButton == null) return;
        boolean playing = canvas.getMode() == OverlayCanvas.Mode.PLAY;
        goButton.setText(playing ? "✎ AJUSTAR" : "▶ JOGAR");
        if (canvas.isAutomaticMode())
            status.setText(canvas.isTracking() ? "AUTO • rastreando mesa" : "AUTO • procurando bolas/guia");
        else status.setText(playing ? "MANUAL • toque no jogo" :
                "AJUSTE • " + canvas.getMode().name());
        if (autoButton!=null) autoButton.setText(!captureActive ? "AUTO: ABRIR" :
                (canvas.isAutomaticMode() ? "AUTO: PAUSAR" : "AUTO: RETOMAR"));
        bouncesButton.setText("REBOTES: " + canvas.getBounces());
        lengthButton.setText(canvas.isLongTrack() ? "RASTRO: LONGO" : "RASTRO: CURTO");
    }

    private void toggleCollapsed() {
        collapsed = !collapsed;
        options.setVisibility(collapsed ? View.GONE : View.VISIBLE);
        collapseButton.setText(collapsed ? "+" : "−");
        manager.updateViewLayout(panel, panelLp);
    }

    private void startStatusNotification(boolean automatic) {
        NotificationManager n = (NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        n.createNotificationChannel(new NotificationChannel(CHANNEL, "Guia de mira ativo",
                NotificationManager.IMPORTANCE_LOW));
        PendingIntent open = PendingIntent.getActivity(this, 0,
                new Intent(this, MainActivity.class), PendingIntent.FLAG_IMMUTABLE |
                PendingIntent.FLAG_UPDATE_CURRENT);
        PendingIntent exit = PendingIntent.getService(this, 1,
                new Intent(this, AimOverlayService.class).setAction(ACTION_STOP),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification notification = new Notification.Builder(this, CHANNEL)
                .setSmallIcon(com.kindmops.mirarastro.R.drawable.ic_launcher)
                .setContentTitle("Mira Rastro ativo")
                .setContentText("Toque para abrir controles")
                .setContentIntent(open)
                .addAction(new Notification.Action.Builder(
                        android.R.drawable.ic_menu_close_clear_cancel, "Desligar", exit).build())
                .setOngoing(true)
                .build();
        if (Build.VERSION.SDK_INT >= 34) {
            int types=ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE;
            if (automatic || captureActive)
                types |= ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION;
            startForeground(NOTIFICATION_ID, notification, types);
        } else {
            startForeground(NOTIFICATION_ID, notification);
        }
    }

    /** A sessão é iniciada somente após o sistema conceder captura de tela. */
    private void startCapture(Intent consent) {
        stopCapture();
        try {
            MediaProjectionManager mp=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
            Intent data;
            if (Build.VERSION.SDK_INT>=33)
                data=consent.getParcelableExtra(EXTRA_RESULT_DATA,Intent.class);
            else data=consent.getParcelableExtra(EXTRA_RESULT_DATA);
            if (data==null) throw new IllegalArgumentException("Token de captura ausente");
            projection=mp.getMediaProjection(consent.getIntExtra(EXTRA_RESULT_CODE,-1),data);
            if (projection==null) throw new IllegalStateException("Captura nao iniciada");
            projectionCallback=new MediaProjection.Callback() {
                @Override public void onStop() {
                    mainHandler.post(() -> {
                        releaseCapture();
                        if (canvas!=null) canvas.setAutomaticMode(false);
                        refresh();
                    });
                }
                @Override public void onCapturedContentResize(int width, int height) {
                    mainHandler.post(() -> resizeCapture(width,height));
                }
            };
            projection.registerCallback(projectionCallback,mainHandler);
            captureThread=new HandlerThread("mira-capture");captureThread.start();
            captureHandler=new Handler(captureThread.getLooper());
            Point size=new Point();
            manager.getDefaultDisplay().getRealSize(size);
            DisplayMetrics metrics=new DisplayMetrics();
            manager.getDefaultDisplay().getMetrics(metrics);
            imageReader=newReader(size.x,size.y);
            virtualDisplay=projection.createVirtualDisplay("MiraRastro-Screen",
                    size.x,size.y,metrics.densityDpi,
                    DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                    imageReader.getSurface(),null,captureHandler);
            captureActive=true;
            canvas.setAutomaticMode(true);
            canvas.setMode(OverlayCanvas.Mode.PLAY);
            setCanvasTouchable(false);
        } catch(Exception ex) {
            android.util.Log.e("MiraRastro","Captura indisponivel",ex);
            stopCapture();
            if (canvas!=null) canvas.setAutomaticMode(false);
        }
    }

    private ImageReader newReader(int width,int height) {
        ImageReader r=ImageReader.newInstance(Math.max(1,width),Math.max(1,height),
                PixelFormat.RGBA_8888,2);
        r.setOnImageAvailableListener(this::onImageAvailable,captureHandler);
        return r;
    }

    private void resizeCapture(int width,int height) {
        if(!captureActive || width<16 || height<16 || virtualDisplay==null) return;
        try {
            ImageReader next=newReader(width,height);
            virtualDisplay.resize(width,height,getResources().getDisplayMetrics().densityDpi);
            virtualDisplay.setSurface(next.getSurface());
            ImageReader old=imageReader;imageReader=next;
            if(old!=null){old.setOnImageAvailableListener(null,null);old.close();}
            previousCue=null;previousAim=null;
        } catch(Exception e){android.util.Log.w("MiraRastro","Falha ao redimensionar",e);}
    }

    private void onImageAvailable(ImageReader reader) {
        Image image=null;
        try {
            image=reader.acquireLatestImage();
            if(image==null || !captureActive || canvas==null || !canvas.isAutomaticMode())return;
            long time=SystemClock.elapsedRealtime();
            if(time-lastFrameAt<250)return;
            lastFrameAt=time;
            int w=image.getWidth(),h=image.getHeight();
            Image.Plane plane=image.getPlanes()[0];
            int stride=plane.getRowStride(),pixelStride=plane.getPixelStride();
            if(pixelStride<4)return;
            int sample=Math.max(1,(Math.max(w,h)+719)/720);
            int dw=w/sample,dh=h/sample;
            if(dw<30 || dh<30)return;
            int[] rgb=new int[dw*dh];
            ByteBuffer buffer=plane.getBuffer();
            for(int y=0;y<dh;y++) {
                int base=y*sample*stride;
                for(int x=0;x<dw;x++) {
                    int at=base+x*sample*pixelStride;
                    int r=buffer.get(at)&255,g=buffer.get(at+1)&255,b=buffer.get(at+2)&255;
                    rgb[y*dw+x]=0xFF000000|(r<<16)|(g<<8)|b;
                }
            }
            ShotPhysics.Rect table=canvas.getTableBounds();
            if(table==null)return;
            float sx=dw/(float)Math.max(1,canvas.getWidth());
            float sy=dh/(float)Math.max(1,canvas.getHeight());
            FrameDetector.State state=new FrameDetector(rgb,dw,dh).detect(
                table.left*sx,table.top*sy,table.right*sx,table.bottom*sy,
                canvas.getRadius()*Math.min(sx,sy),previousCue,previousAim);
            if(state.cue!=null)previousCue=state.cue;
            if(state.direction!=null)previousAim=state.direction;
            final FrameDetector.State result=state;
            canvas.post(() -> {
                if(canvas!=null)canvas.setDetectedFrame(result,dw,dh);
                refresh();
            });
        } catch(Exception e) {
            android.util.Log.w("MiraRastro","Quadro ignorado",e);
        } finally {if(image!=null)image.close();}
    }

    private void releaseCapture() {
        captureActive=false;
        if (virtualDisplay!=null) {virtualDisplay.release();virtualDisplay=null;}
        if (imageReader!=null) {
            imageReader.setOnImageAvailableListener(null,null);
            imageReader.close();imageReader=null;
        }
        if(captureThread!=null){captureThread.quitSafely();captureThread=null;captureHandler=null;}
        previousCue=null;previousAim=null;
    }
    private void stopCapture() {
        releaseCapture();
        if (projection!=null) {
            MediaProjection mp=projection;projection=null;
            try{mp.stop();}catch(Exception ignored){}
        }
    }

    @Override public void onDestroy() {
        stopCapture();
        if (manager != null) {
            if (panel != null) {
                try { manager.removeView(panel); } catch (IllegalArgumentException ignored) {}
            }
            if (canvas != null) {
                try { manager.removeView(canvas); } catch (IllegalArgumentException ignored) {}
            }
        }
        panel = null; canvas = null;
        super.onDestroy();
    }
}
