'use strict';
const fs=require('node:fs');
const path=require('node:path');

function validServerUrl(value){
  const u=new URL(String(value||''));
  if(u.username||u.password||u.search||u.hash||u.pathname!=='/')throw Error('Use somente a URL raiz do servidor');
  const isLocal=['localhost','127.0.0.1','[::1]'].includes(u.hostname);
  if(u.protocol!=='https:'&&!(isLocal&&u.protocol==='http:'))throw Error('Servidor remoto exige HTTPS');
  return u.origin;
}
function createSharedCenter({file,crypto,fetchImpl=fetch}={}){
  if(!file)throw Error('Caminho de configuração obrigatório');
  let serverUrl='',token='',stored='',lastError='',lastSynced=0;
  try{
    const saved=JSON.parse(fs.readFileSync(file,'utf8'));
    serverUrl=validServerUrl(saved.serverUrl);
    stored=String(saved.encryptedToken||'');
    if(stored&&crypto?.isEncryptionAvailable?.())token=crypto.decryptString(Buffer.from(stored,'base64'));
  }catch{serverUrl='';stored=''}
  const headers=()=>({'Authorization':`Bearer ${token}`,'Content-Type':'application/json'});
  const ready=()=>Boolean(serverUrl&&/^[a-z0-9_-]{20,200}$/i.test(token));
  async function request(method,route,data){
    if(!ready())throw Error('Configure a URL e o token da central');
    const response=await fetchImpl(serverUrl+route,{method,headers:headers(),
      ...(data===undefined?{}:{body:JSON.stringify(data)}),signal:AbortSignal.timeout(10000)});
    const result=await response.json().catch(()=>({}));
    if(!response.ok)throw Error(String(result.error||`Central: HTTP ${response.status}`));
    return result;
  }
  function publicConfig(){return {configured:ready(),serverUrl,tokenStored:!!stored,lastError,lastSynced}}
  async function configure(input){
    const url=validServerUrl(input.serverUrl);
    const nextToken=String(input.token||token).trim();
    if(!/^[a-z0-9_-]{20,200}$/i.test(nextToken))throw Error('Token da central inválido');
    const old={serverUrl,token};serverUrl=url;token=nextToken;
    let profile;
    try{profile=await request('GET','/api/state')}catch(e){Object.assign(old,{});serverUrl=old.serverUrl;token=old.token;throw e}
    const encrypted=crypto?.isEncryptionAvailable?.()?crypto.encryptString(token).toString('base64'):'';
    const payload={serverUrl,encryptedToken:encrypted};
    fs.mkdirSync(path.dirname(file),{recursive:true});
    fs.writeFileSync(file,JSON.stringify(payload),{mode:0o600});
    stored=encrypted;lastError='';
    return {config:publicConfig(),state:profile};
  }
  async function getState(){return request('GET','/api/state')}
  async function setSharing(sharing){return request('POST','/api/profile',{sharing:!!sharing})}
  async function sync(snapshot){
    if(!snapshot?.ready||!ready())return null;
    // Impede compartilhar dados de outra conta/mundo com o token salvo.
    const state=await getState();
    const me=state.users?.find(u=>u.id===state.selfId);
    if(String(state.world)!==snapshot.world||String(me?.playerId)!==snapshot.playerId)
      throw Error('Token pertence a outro mundo ou jogador; sincronização bloqueada');
    const result=await request('POST','/api/sync',{movements:snapshot.movements,alliance:snapshot.alliance});
    lastSynced=Date.now();lastError='';return result;
  }
  function failed(error){lastError=String(error?.message||error)}
  function clear(){serverUrl='';token='';stored='';lastSynced=0;lastError='';try{fs.unlinkSync(file)}catch{}}
  return {publicConfig,configure,getState,setSharing,sync,failed,clear,ready};
}
module.exports={createSharedCenter,validServerUrl};
